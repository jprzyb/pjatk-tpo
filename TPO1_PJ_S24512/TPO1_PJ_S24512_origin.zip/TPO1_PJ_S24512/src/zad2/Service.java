/**
 *
 *  @author Przybylski Jakub S24512
 *
 */

package zad2;


public class Service {
}  
